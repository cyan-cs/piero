/* utils */
int util(void) { return 1; }
